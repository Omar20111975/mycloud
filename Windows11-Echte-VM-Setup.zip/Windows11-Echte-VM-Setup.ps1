# Windows 11 echte VM-installatiehulp
# Dit script maakt een ECHTE Windows 11 virtuele machine in Hyper-V.
# Het bevat Windows zelf NIET; gebruik een officiële Microsoft Windows 11 ISO.
# Vereist: Windows 10/11 Pro/Enterprise/Education met Hyper-V, beheerderrechten,
# minimaal 8 GB RAM aanbevolen, en voldoende vrije opslag.

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "=== Windows 11 VM Setup ===" -ForegroundColor Cyan
Write-Host "Dit maakt een echte Windows 11 VM met UEFI/Secure Boot/TPM 2.0."
Write-Host ""

# Administrator check
$id = [Security.Principal.WindowsIdentity]::GetCurrent()
$p = New-Object Security.Principal.WindowsPrincipal($id)
if (-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "Start PowerShell als Administrator en voer dit script opnieuw uit." -ForegroundColor Red
    pause
    exit 1
}

# Hyper-V check
$hv = Get-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V-All
if ($hv.State -ne "Enabled") {
    Write-Host "Hyper-V staat niet aan." -ForegroundColor Yellow
    Write-Host "Je kunt Hyper-V inschakelen met:"
    Write-Host "  Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V -All"
    Write-Host "Daarna moet Windows mogelijk opnieuw worden gestart."
    pause
    exit 1
}

$vmName = Read-Host "Naam van de VM [Windows 11]"
if ([string]::IsNullOrWhiteSpace($vmName)) { $vmName = "Windows 11" }

$iso = Read-Host "Volledig pad naar je officiële Windows 11 ISO"
if (-not (Test-Path $iso)) {
    Write-Host "ISO niet gevonden: $iso" -ForegroundColor Red
    pause
    exit 1
}

$base = Read-Host "Opslagmap [C:\Hyper-V\$($vmName.Replace(' ','_'))]"
if ([string]::IsNullOrWhiteSpace($base)) {
    $base = "C:\Hyper-V\$($vmName.Replace(' ','_'))"
}

$ramGB = Read-Host "RAM in GB [8]"
if (-not $ramGB) { $ramGB = 8 }
$ram = [int64]$ramGB * 1GB

$diskGB = Read-Host "Virtuele schijf in GB [100]"
if (-not $diskGB) { $diskGB = 100 }
$diskSize = [int64]$diskGB * 1GB

if (Get-VM -Name $vmName -ErrorAction SilentlyContinue) {
    Write-Host "Er bestaat al een VM met deze naam." -ForegroundColor Red
    pause
    exit 1
}

New-Item -ItemType Directory -Path $base -Force | Out-Null
$vhd = Join-Path $base "$($vmName.Replace(' ','_')).vhdx"

Write-Host "Virtuele schijf maken..."
New-VHD -Path $vhd -SizeBytes $diskSize -Dynamic | Out-Null

Write-Host "Windows 11 VM maken..."
New-VM -Name $vmName -Generation 2 -MemoryStartupBytes $ram -VHDPath $vhd | Out-Null

Set-VM -Name $vmName -ProcessorCount 4 -AutomaticStopAction ShutDown
Set-VMFirmware -VMName $vmName -EnableSecureBoot On -SecureBootTemplate "MicrosoftWindows"
Set-VMKeyProtector -VMName $vmName -NewLocalKeyProtector
Enable-VMTPM -VMName $vmName

# DVD/ISO koppelen
$dvd = Add-VMDvdDrive -VMName $vmName -Path $iso -Passthru
Set-VMFirmware -VMName $vmName -FirstBootDevice $dvd

Write-Host ""
Write-Host "Klaar!" -ForegroundColor Green
Write-Host "VM: $vmName"
Write-Host "RAM: $ramGB GB"
Write-Host "Schijf: $diskGB GB"
Write-Host ""
Write-Host "De echte Windows 11 installatie start nu."
Write-Host "Open 'Hyper-V Manager', kies '$vmName' en klik Verbinden > Starten."
Write-Host ""
Write-Host "Na Windows-installatie:"
Write-Host "1. Open Edge in de VM."
Write-Host "2. Ga naar https://www.google.com/chrome/"
Write-Host "3. Installeer Google Chrome."
Write-Host ""
Write-Host "Microsoft Windows 11 is gelicentieerde software. Dit script omzeilt geen licentie."
Write-Host "Voor onbeperkt gebruik heb je een geldige Windows-licentie nodig."
Write-Host ""
Start-Process "virtmgmt.msc"
